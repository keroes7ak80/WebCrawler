To run Crawler Run MainCrawler.java

To run Indexer Run MainIndexer.java
