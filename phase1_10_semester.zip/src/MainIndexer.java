public class MainIndexer {
    public static void main(String args[]) throws Exception {
        Indexer idx=new Indexer();
        idx.MainIndexer();
    }
}
